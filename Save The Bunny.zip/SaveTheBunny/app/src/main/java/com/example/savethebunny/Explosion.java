package com.example.savethebunny;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class Explosion {
    public int explosionX;
    Bitmap explosion[] = new Bitmap[4];
    int explosionFrame = 0 ;
    int explosionx , explosionY;

    public Explosion(Context context){
        explosion[0] = BitmapFactory.decodeResource(context.getResources(),R.drawable.spike);
        explosion[1] = BitmapFactory.decodeResource(context.getResources(),R.drawable.spike);
        explosion[2] = BitmapFactory.decodeResource(context.getResources(),R.drawable.spike2);
        explosion[3] = BitmapFactory.decodeResource(context.getResources(),R.drawable.spike3);
    }
    public Bitmap getExplosion(int explosionFrame){
        return explosion[explosionFrame];
    }
}
